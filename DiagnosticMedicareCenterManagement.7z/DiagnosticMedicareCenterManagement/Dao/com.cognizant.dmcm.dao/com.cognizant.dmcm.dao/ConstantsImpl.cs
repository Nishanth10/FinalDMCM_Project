﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.dao {
    public class ConstantsImpl {
        public static string _id = "@id";
        public static string _service = "@service";
        public static string _description = "@description";
        public static string _amount = "@amount";

        public static string _medicareServiceTableId = "ms_id";
        public static string _medicareServiceTableService = "ms_service";
        public static string _medicareServiceTableDescription = "ms_description";
        public static string _medicareServiceTableAmount = "ms_amount";

        public static string _firstName = "@firstName";
        public static string _lastName = "@lastName";
        public static string _age = "@age";
        public static string _gender = "@gender";
        public static string _dob = "@dob";
        public static string _phone = "@phone";
        public static string _alternatePhone = "@altphone";
        public static string _email = "@email";
        public static string _password = "@password";
        public static string _address_line1 = "@address_line1";
        public static string _address_line2 = "@address_line2";
        public static string _city = "@city";
        public static string _state = "@state";
        public static string _zipcode = "@zipcode";
        public static string _degree = "@degree";
        public static string _speciality = "@speciality";
        public static string _workHours = "@work_hours";
        public static string _clinicName = "@clinic_name";
        public static string _medicareServiceId = "@medicareServiceId";

        public static string _patientStatus = "@patientStatus";
        public static string _patientStatusTable = "pt_status";



        public static string _doctorId = "do_id";
        public static string _doctorPassword = "do_password";

        public static string _addressLine1 = "@addressLine1";
        public static string _addressLine2 = "@addressLine2";

        public static string _patientId = "pt_id";
        public static string _patientPassword = "pt_password";
        public static string _patientEmail = "pt_email";


        public static string _reportId = "@reportId";
        public static string _ptId = "@patientId";
        public static string _doId = "@doctorId";
        public static string _serviceDate = "@serviceDate";
        public static string _testResultDate = "@testResultDate";
        public static string _diag1ActualValue = "@diag1ActualValue";
        public static string _diag1NormalRange = "@diag1NormalRange";
        public static string _diag2ActualValue = "@diag2ActualValue";
        public static string _diag2NormalRange = "@diag2NormalRange";
        public static string _diag3ActualValue = "@diag3ActualValue";
        public static string _diag3NormalRange = "@diag3NormalRange";
        public static string _diag4ActualValue = "@diag4ActualValue";
        public static string _diag4NormalRange = "@diag4NormalRange";
        public static string _diag5ActualValue = "@diag5ActualValue";
        public static string _diag5NormalRange = "@diag5NormalRange";
        public static string _diag6ActualValue = "@diag6ActualValue";
        public static string _diag6NormalRange = "@diag6NormalRange";
        public static string _doctorComments = "@doctorComments";
        public static string _otherInfo = "@otherInfo";

        public static string _rId = "mth_id";
        public static string _pId = "mth_pt_id";
        public static string _dId = "mth_do_id";
        public static string _msId = "mth_ms_id";
        public static string _sDate = "mth_service_date";
        public static string _tResultDate = "mth_test_result_date";
        public static string _d1ActualValue = "mth_diag1_actual_value";
        public static string _d1NormalRange = "mth_diag1_normal_range";
        public static string _d2ActualValue = "mth_diag2_actual_value";
        public static string _d2NormalRange = "mth_diag2_normal_range";
        public static string _d3ActualValue = "mth_diag3_actual_value";
        public static string _d3NormalRange = "mth_diag3_normal_range";
        public static string _d4ActualValue = "mth_diag4_actual_value";
        public static string _d4NormalRange = "mth_diag4_normal_range";
        public static string _d5ActualValue = "mth_diag5_actual_value";
        public static string _d5NormalRange = "mth_diag5_normal_range";
        public static string _d6ActualValue = "mth_diag6_actual_value";
        public static string _d6NormalRange = "mth_diag6_normal_range";
        public static string _dComments = "mth_doctors_comments";
        public static string _oInfo = "mth_other_info";

        public static string _date = "@date";

        public static string _status = "@status";

        public static string _appointmentStatus = "@appointmentStatus";
        public static string _reportStatus = "@reportStatus";
        public static string _approveStatus = "@approveStatus";
        public static string _reportUnavailableStatus = "Unavailable";
        public static string _rpUnavailableStatus = "@reportUnavailableStatus";
        public static string _reportAvailableStatus = "Available";
        public static string _rpAvailableStatus = "@reportAvailableStatus";

        public static string _ptFirstName = "pt_first_name";

        public static string _ptLastName = "pt_last_name";

        public static string _apDate = "ap_date";

        public static string _apStatus = "ap_status";

        public static string _availableStatus = "Available";

        public static string _unavailableStatus = "Unavailable";

        public static string _approveValue = "Approved";
        public static string _rejectValue = "Rejected";


        public static string _adminId = "ad_id";
        public static string _adminPassword = "ad_password";
        public static string _adminEmail = "ad_email";

        public static string _doFirstName = "do_first_name";
        public static string _doLastName = "do_last_name";
        public static string _doSpeciality = "do_speciality";
        public static string _doPhone = "do_phone";
        public static string _doEmail = "do_email";
        public static string _doWorkHours = "do_work_hours";
        public static string _doMsId = "do_medicare_service_id";



        public static string _doctorStatus = "@doctorStatus";
        
        public static string _doctorStatusTable = "do_status";

        public static string _stringActive = "Active";
        public static string _stringInactive = "Inactive";

        public static string _adminFirstName = "ad_first_name";
        public static string _adminLastName = "ad_last_name";


        public static string _rpStatus = "ap_rp_status";
    }
}
