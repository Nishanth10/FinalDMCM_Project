﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao {
    public class MedicareServiceDaoSqlImpl : IMedicareServiceDao {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        public int AddMedicareService(MedicareServices medicareServices) {
            int result = 0;
                using (SqlConnection connnection = new SqlConnection(callConnection)) {
                    connnection.Open();
                    SqlCommand sqlCommand = new SqlCommand {
                        Connection = connnection,
                        CommandType = CommandType.Text,
                        CommandText = QueriesImpl._addMedicareService
                    };

                    sqlCommand.Parameters.Add(ConstantsImpl._service, SqlDbType.VarChar).Value = medicareServices.MedicareServiceName;
                    sqlCommand.Parameters.Add(ConstantsImpl._description, SqlDbType.VarChar).Value = medicareServices.MedicareDescription;
                    sqlCommand.Parameters.Add(ConstantsImpl._amount, SqlDbType.BigInt).Value = medicareServices.MedicareAmount;

                    result = sqlCommand.ExecuteNonQuery();
                }
            
            return result;
        }

        public List<MedicareServices> GetAllMedicareServices() {
            List<MedicareServices> medicareServicesList = new List<MedicareServices>();
            using (SqlConnection connection = new SqlConnection(callConnection)) {
                connection.Open();
                SqlCommand sqlcommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getAllMedicareServices
                };

                SqlDataReader dataReader = sqlcommand.ExecuteReader();

                while (dataReader.Read()) {
                    MedicareServices medicareServices = new MedicareServices();
                    medicareServices.MedicareServiceId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableId)));
                    medicareServices.MedicareServiceName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableService)));
                    medicareServices.MedicareDescription = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableDescription)));
                    medicareServices.MedicareAmount = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableAmount)));
                    medicareServicesList.Add(medicareServices);
                }
                return medicareServicesList;
            }            
        }

        public MedicareServices GetSpecificMedicareServicesById(long medicareServiceId) {
            using (SqlConnection connection = new SqlConnection(callConnection)) {
                connection.Open();
                SqlCommand sqlcommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getSpecificMedicareServicesById
                };

                sqlcommand.Parameters.Add(ConstantsImpl._id, SqlDbType.Int).Value = medicareServiceId;
                SqlDataReader dataReader = sqlcommand.ExecuteReader();
                MedicareServices medicareServices = new MedicareServices();

                while (dataReader.Read()) {
                    medicareServices.MedicareServiceId = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableId)));
                    medicareServices.MedicareServiceName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableService)));
                    medicareServices.MedicareDescription = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableDescription)));
                    medicareServices.MedicareAmount = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._medicareServiceTableAmount)));
                }
                return medicareServices;
            }

        }

        public int  ModifyMedicareService(MedicareServices medicareService) {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._updateMedicareServices
                };

                sqlCommand.Parameters.Add(ConstantsImpl._service, SqlDbType.VarChar).Value = medicareService.MedicareServiceName;
                sqlCommand.Parameters.Add(ConstantsImpl._description, SqlDbType.VarChar).Value = medicareService.MedicareDescription;
                sqlCommand.Parameters.Add(ConstantsImpl._amount, SqlDbType.BigInt).Value = medicareService.MedicareAmount;
                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.BigInt).Value = medicareService.MedicareServiceId;

                result = sqlCommand.ExecuteNonQuery();
            }
            return result;
        }
    }
}
