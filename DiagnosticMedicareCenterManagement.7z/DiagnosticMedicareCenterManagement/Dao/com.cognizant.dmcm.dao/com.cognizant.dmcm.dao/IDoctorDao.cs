﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao
{
    interface IDoctorDao
    {
        int DoctorRegistration(Doctor doctor);

        int DoctorLogin(String DoctorId, string password);

        int GetDoctorMedicareId(string doctorId);
        int GetMedicareServiceId(string speciality);
        int GetMail(string email);
        List<Doctor> DisplayDoctor();
        int DoctorStatusApprove(Doctor doctor);
        int DoctorStatusReject(Doctor doctor);
        Doctor DisplaySpecficDoctorById(string id);
        Doctor GetDoctor(string doctorId);
        List<Doctor> GetDoctorList();
        string GetDoctorName(string doctorId);
        Doctor DisplaySpecificDoctor(string email);
    }
}
