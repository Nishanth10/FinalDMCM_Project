﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.dmcm.model;
namespace com.cognizant.dmcm.dao
{
    interface IPatientDao
    {
        int PatientRegistration(Patient patient);
        int PatientLogin(string patientId, string password);
        int GetMail(string email);
        List<Patient> DisplayPatient();
        int PatientStatusApprove(Patient patient);
        int PatientStatusReject(Patient patient);
        string GetPatientName(string patientId);
        List<Patient> DisplayAvailablePatientReport(string doctorId);
        List<Patient> DisplayUnavailablePatientReport(string doctorId);
        Patient DisplaySpecficPatientById(string id);
        void UpdateReportStatus(string patientId, string doctorId);
        Patient DisplaySpecificPatient(string email);
    }
}
