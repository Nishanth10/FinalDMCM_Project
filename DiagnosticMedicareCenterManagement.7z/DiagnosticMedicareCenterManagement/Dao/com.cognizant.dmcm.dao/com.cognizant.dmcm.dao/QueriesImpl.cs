﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.dao
{
    public class QueriesImpl
    {
        public static string _addMedicareService = "insert into [medicare_services] values(@service,@description,@amount)";
        public static string _getAllMedicareServices = "select * from [medicare_services](nolock)";
        public static string _updateMedicareServices = "update [medicare_services] set ms_service=@service,ms_description=@description,ms_amount=@amount where ms_id=@id";
        public static string _getSpecificMedicareServicesById = "select * from [medicare_services](nolock) where ms_id=@id";

        
        public static string _addHistory = "insert into [medical_test_history] values(@patientId,@doctorId,@medicareServiceId,@serviceDate,@testResultDate,@diag1ActualValue,@diag1NormalRange,@diag2ActualValue,@diag2NormalRange,@diag3ActualValue,@diag3NormalRange,@diag4ActualValue,@diag4NormalRange,@diag5ActualValue,@diag5NormalRange,@diag6ActualValue,@diag6NormalRange,@doctorComments,@otherInfo)";
        public static string _viewMedicalHistory = "select * from [medical_test_history] (nolock)";
        public static string _displayFilteredMedicalHistoryById = "select * from [medical_test_history] (nolock) where mth_pt_id =@patientId";
        public static string _displayFilteredMedicalDoctorHistoryById = "select * from [medical_test_history] (nolock) where mth_pt_id =@patientId and mth_do_id=@doctorId and mth_service_date=@serviceDate;";
        public static string _updateMedicalHistory = "update [medical_test_history] set mth_test_result_date=@testResultDate,mth_diag1_actual_value=@diag1ActualValue,mth_diag1_normal_range=@diag1NormalRange,	mth_diag2_actual_value=@diag2ActualValue,mth_diag2_normal_range=@diag2NormalRange,mth_diag3_actual_value=@diag3ActualValue,mth_diag3_normal_range=@diag3NormalRange,mth_diag4_actual_value=@diag4ActualValue,mth_diag4_normal_range=@diag4NormalRange,mth_diag5_actual_value=@diag5ActualValue,mth_diag5_normal_range=@diag5NormalRange,mth_diag6_actual_value=@diag6ActualValue,mth_diag6_normal_range=@diag6NormalRange,mth_doctors_comments=@doctorComments,mth_other_info=@otherInfo where mth_pt_id=@patientId and mth_do_id=@doctorId and mth_service_date=@serviceDate";

        public static string _registerPatient = "insert into [patient] values(@firstName,@lastName,@age,@gender,@dob,@phone,@altphone,@email,@password,@addressLine1,@addressLine2,@city,@state,@zipcode,@patientStatus)";

        public static string _patientListCreateReport = "select pt_id,pt_first_name,pt_last_name,pt_gender,pt_phone,ap_rp_status,ap_date from patient (nolock) pa inner join appointment (nolock) ap on pa.pt_id=ap.ap_pt_id where ap.ap_do_id= @doctorId and ap_status = @approveStatus and ap_rp_status=@reportUnavailableStatus";
        public static string _patientListViewReport = "select pt_id,pt_first_name,pt_last_name,pt_gender,pt_phone,ap_rp_status,ap_date from patient (nolock) pa inner join appointment (nolock) ap on pa.pt_id=ap.ap_pt_id where ap.ap_do_id= @doctorId and ap_status = @approveStatus and ap_rp_status=@reportAvailableStatus";
        public static string _displayFilteredPatientByID = "select * from [patient](nolock) where pt_id=@id";

        public static string _viewDoctorAppointment = "select pt.pt_id,pt.pt_first_name ,pt.pt_last_name ,ap.ap_date,ap.ap_status from [patient] as pt inner join [appointment] ap on pt.pt_id = ap.ap_pt_id where ap.ap_do_id = @doctorId;";
        public static string _updateStatus = "update appointment set ap_status = @status,ap_rp_status=@reportStatus where ap_pt_id = @patientId and ap_do_id = @doctorId and ap_date=@date;";
        public static string _checkDate = "select ap.ap_date from [appointment] as ap where ap.ap_pt_id = @patientId and ap.ap_do_id = @doctorId;";
        public static string _updateReportStatus = "UPDATE[appointment] SET ap_rp_status=@reportStatus WHERE ap_pt_id = @patientId and ap_do_id=@doctorId";    
        public static string _registerAdmin = "insert into [admin] values(@firstName,@lastName,@age,@gender,@dob,@phone,@altphone,@email,@password)";
        public static string _loginAdmin = "select * from [admin] (nolock)";
        public static string _doctorList = "select do_id,do_first_name,do_last_name,do_status from [doctor] (nolock)";
        public static string _patientListDisplay = "select pt_id,pt_first_name,pt_last_name,pt_status from [patient] (nolock)";
        public static string _updatePatientStatus = "update [patient] set pt_status=@patientStatus where pt_id=@id";
        public static string _updateDoctorStatus = "update [doctor] set do_status=@doctorStatus where do_id=@id";      
        public static string _displayFilteredDoctorByID = "select * from [doctor] where do_id=@id;";
        public static string _adminName = "select * from [admin] (nolock) where ad_id=@id";      
        public static string _loginPatient = "select * from [patient] (nolock) where pt_id=@id";
        public static string _registerDoctor = "insert into [doctor] values(@firstName,@lastName,@age,@gender,@dob,@phone,@altphone,@email,@password,@address_line1,@address_line2,@city,@state,@zipcode,@degree,@speciality,@work_hours,@clinic_name,@medicareServiceId,@doctorStatus)";
        public static string _loginDoctor = "select * from [doctor] (nolock) where do_id=@id";
        public static string _getDoctor = "select * from [doctor] (nolock)";

        public static string _getDoctorById = "select * from [doctor] as do where do.do_id = @doctorId;";
        public static string _bookAppointment = "insert into [appointment] values(@patientId,@doctorId,@medicareServiceId,@date,@status,@reportStatus)";       
        public static string _viewPatientAppointment = "select do.do_first_name ,do.do_last_name ,ap.ap_date ,ap.ap_status from [doctor] as do inner join [appointment] as ap on do.do_id = ap.ap_do_id where ap.ap_pt_id = @patientId;";
        public static string _getPatientName = "select pt.pt_first_name,pt.pt_last_name from [patient] as pt where pt.pt_id = @patientId";
        public static string _getDoctorName = "select do.do_first_name,do.do_last_name from [doctor] as do where do.do_id = @doctorId";




        public static string _displayFilteredUser = "select do_id,do_first_name,do_last_name from [doctor] where do_email = @email";
        public static string _displayFilteredPatient = "select pt_id,pt_first_name,pt_last_name from [patient] where pt_email = @email";

        public static string _getMedicareServiceId = "select ms.ms_id from [medicare_services] as ms where ms.ms_service = @speciality;";
        public static string _getMedicareId = "select do.do_medicare_service_id from [doctor] as do where do.do_id = @doctorId;";

        public static string _getDoctorEmail = "select do.do_email from [doctor] as do;";
        public static string _getPatientEmail = "select pt.pt_email from [patient] as pt;";
        public static string _getAdminEmail = "select ad.ad_email from [admin] as ad;";
    }
}
