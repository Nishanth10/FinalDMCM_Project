﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao {
    public class PatientDaoSqlImpl : IPatientDao {
        static string _callConnection = ConnectionHandler.ConnectionVariable;
        public int PatientRegistration(Patient patient) {
            int result = 0;
            int checkEmail = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._registerPatient
                };

                sqlCommand.Parameters.Add(ConstantsImpl._firstName, SqlDbType.VarChar).Value = patient.FirstName;
                sqlCommand.Parameters.Add(ConstantsImpl._lastName, SqlDbType.VarChar).Value = patient.LastName;
                sqlCommand.Parameters.Add(ConstantsImpl._age, SqlDbType.Int).Value = patient.Age;
                sqlCommand.Parameters.Add(ConstantsImpl._gender, SqlDbType.VarChar).Value = patient.Gender;
                sqlCommand.Parameters.Add(ConstantsImpl._dob, SqlDbType.VarChar).Value = patient.DateOfBirth;
                sqlCommand.Parameters.Add(ConstantsImpl._phone, SqlDbType.BigInt).Value = patient.Phone;
                if (patient.AlternatePhone == 0) {
                    sqlCommand.Parameters.Add(ConstantsImpl._alternatePhone, SqlDbType.BigInt).Value = 0;
                }
                else if (patient.Phone == patient.AlternatePhone) {
                    result = 3;
                    return result;
                }
                else {
                    sqlCommand.Parameters.Add(ConstantsImpl._alternatePhone, SqlDbType.BigInt).Value = patient.AlternatePhone;
                }
                checkEmail = GetMail(patient.Email);
                if (checkEmail == 1) {
                    result = 2;
                    return result;
                }
                else {
                    sqlCommand.Parameters.Add(ConstantsImpl._email, SqlDbType.VarChar).Value = patient.Email;
                }
                sqlCommand.Parameters.Add(ConstantsImpl._password, SqlDbType.VarChar).Value = patient.Password;
                sqlCommand.Parameters.Add(ConstantsImpl._addressLine1, SqlDbType.VarChar).Value = patient.AddressLine1;
                sqlCommand.Parameters.Add(ConstantsImpl._addressLine2, SqlDbType.VarChar).Value = patient.AddressLine2;
                sqlCommand.Parameters.Add(ConstantsImpl._city, SqlDbType.VarChar).Value = patient.City;
                sqlCommand.Parameters.Add(ConstantsImpl._state, SqlDbType.VarChar).Value = patient.State;
                sqlCommand.Parameters.Add(ConstantsImpl._zipcode, SqlDbType.BigInt).Value = patient.Zipcode;
                sqlCommand.Parameters.Add(ConstantsImpl._patientStatus, SqlDbType.VarChar).Value = "Inactive";

                result = sqlCommand.ExecuteNonQuery();
            }
            return result;
        }

        public int GetMail(string email) {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getPatientEmail
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read()) {
                    if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientEmail))).Equals(email)) {
                        result = 1;
                        break;
                    }
                }
            }
            return result;
        }

        public int PatientLogin(string patientId, string password) {
            int logResult = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._loginPatient
                };
                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = patientId;
                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read()) {
                    if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientId))).Equals(patientId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientPassword))).Equals(password)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientStatusTable))).
                    Equals(ConstantsImpl._approveValue, StringComparison.InvariantCultureIgnoreCase)) {
                        logResult = 1;
                        break;
                    }
                    else if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientId))).Equals(patientId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientPassword))).Equals(password)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientStatusTable))).
                    Equals(ConstantsImpl._stringInactive, StringComparison.InvariantCultureIgnoreCase)) {
                        logResult = 2;
                    }
                    else if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientId))).Equals(patientId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientPassword))).Equals(password)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientStatusTable))).
                    Equals(ConstantsImpl._rejectValue, StringComparison.InvariantCultureIgnoreCase)) {
                        logResult = 4;
                    }
                    else {
                        logResult = 3;
                    }
                }
            }
            return logResult;
        }

        public List<Patient> DisplayPatient() {
            List<Patient> patientList = new List<Patient>();
            using (SqlConnection con = new SqlConnection(_callConnection)) {
                con.Open();
                SqlCommand cmd = new SqlCommand {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._patientListDisplay
                };
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read()) {
                    Patient patient = new Patient();
                    patient.PatientId = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_id")));
                    patient.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_first_name")));
                    patient.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_last_name")));
                    patient.PatientStatus = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_status")));
                    patientList.Add(patient);
                }
                return patientList;
            }
        }

        public int PatientStatusApprove(Patient patient) {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection)) {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._updatePatientStatus
                };
                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = patient.PatientId;
                if (patient.PatientStatus == "Inactive" || patient.PatientStatus == "Rejected") {
                    result = 1;
                    sqlCommand.Parameters.Add(ConstantsImpl._patientStatus, SqlDbType.VarChar).Value = "Approved";
                    sqlCommand.ExecuteNonQuery();
                }
                else  {
                    result = 2;
                }
                return result;
            }
        }

        public int PatientStatusReject(Patient patient)
        {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._updatePatientStatus
                };
                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = patient.PatientId;
                if (patient.PatientStatus == "Approved" || patient.PatientStatus == "Inactive")
                {
                    result = 1;
                    sqlCommand.Parameters.Add(ConstantsImpl._patientStatus, SqlDbType.VarChar).Value = "Rejected";
                    sqlCommand.ExecuteNonQuery();
                }
                else
                {
                    result = 2;
                }
                return result;
            }
        }

        public string GetPatientName(string patientId)
        {
            string patientName = "";
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._getPatientName
                };

                sqlCommand.Parameters.Add(ConstantsImpl._ptId, SqlDbType.VarChar).Value = patientId;

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    patientName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._ptFirstName))) + " " + Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._ptLastName)));
                }
            }
            return patientName;
        }

        public List<Patient> DisplayAvailablePatientReport(string doctorId)

        {
            int count = 0;
            List<Patient> patientList = new List<Patient>();



            using (SqlConnection con = new SqlConnection(_callConnection))

            {

                con.Open();

                SqlCommand cmd = new SqlCommand

                {

                    Connection = con,

                    CommandType = CommandType.Text,

                    CommandText = QueriesImpl._patientListViewReport

                };


                cmd.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;
                cmd.Parameters.Add(ConstantsImpl._approveStatus, SqlDbType.VarChar).Value = ConstantsImpl._approveValue;
                cmd.Parameters.Add(ConstantsImpl._rpAvailableStatus, SqlDbType.VarChar).Value = ConstantsImpl._reportAvailableStatus;
                SqlDataReader dr = cmd.ExecuteReader();



                while (dr.Read())

                {

                    Patient patient = new Patient();

                    patient.PatientId = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_id")));

                    patient.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_first_name")));

                    patient.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_last_name")));

                    patient.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_gender")));

                    patient.Phone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("pt_phone")));

                    patient.ReportStatus = Convert.ToString(dr.GetValue(dr.GetOrdinal("ap_rp_status")));

                    patient.AppointmentDate = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal(ConstantsImpl._apDate)));

                    if (patient.ReportStatus.ToString().Equals(ConstantsImpl._availableStatus,StringComparison.InvariantCultureIgnoreCase))
                    {
                        count++;
                        patientList.Add(patient);
                        
                    }

                }
                if (count == 0)
                {
                    throw new AppointmentEmptyException("No Record to Display");
                }



            }
            return patientList;
        }

        public List<Patient> DisplayUnavailablePatientReport(string doctorId)

        {

            List<Patient> patientList = new List<Patient>();



            using (SqlConnection con = new SqlConnection(_callConnection))

            {
                int count = 0;
                con.Open();

                SqlCommand cmd = new SqlCommand

                {

                    Connection = con,

                    CommandType = CommandType.Text,

                    CommandText = QueriesImpl._patientListCreateReport

                };

                cmd.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;
                cmd.Parameters.Add(ConstantsImpl._approveStatus, SqlDbType.VarChar).Value = ConstantsImpl._approveValue;
                cmd.Parameters.Add(ConstantsImpl._rpUnavailableStatus, SqlDbType.VarChar).Value = ConstantsImpl._reportUnavailableStatus;
                SqlDataReader dr = cmd.ExecuteReader();



                while (dr.Read())

                {

                    Patient patient = new Patient();

                    patient.PatientId = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_id")));

                    patient.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_first_name")));

                    patient.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_last_name")));

                    patient.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_gender")));

                    patient.Phone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("pt_phone")));

                    patient.ReportStatus = Convert.ToString(dr.GetValue(dr.GetOrdinal("ap_rp_status")));
                    patient.AppointmentDate = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal(ConstantsImpl._apDate)));

                    if (patient.ReportStatus.ToString().Equals(ConstantsImpl._unavailableStatus, StringComparison.InvariantCultureIgnoreCase))
                    {
                        count++;
                        patientList.Add(patient);
                        
                    }

                }
                if (count == 0)
                {
                    throw new AppointmentEmptyException("No Record to Display");
                }

            }
            return patientList;
        }

        public Patient DisplaySpecficPatientById(string id)

        {

            using (SqlConnection connection = new SqlConnection(_callConnection))

            {

                connection.Open();

                SqlCommand sqlCommand = new SqlCommand

                {

                    Connection = connection,

                    CommandType = CommandType.Text,

                    CommandText = QueriesImpl._displayFilteredPatientByID

                };



                sqlCommand.Parameters.Add(ConstantsImpl._id, SqlDbType.VarChar).Value = id;

                SqlDataReader dr = sqlCommand.ExecuteReader();

                Patient patient = new Patient();



                while (dr.Read())

                {

                    patient.PatientId = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_id")));

                    patient.FirstName = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_first_name")));

                    patient.LastName = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_last_name")));

                    patient.Age = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("pt_age")));

                    patient.Gender = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_gender")));

                    patient.DateOfBirth = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_Dob")));

                    patient.Phone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("pt_phone")));

                    patient.AlternatePhone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("pt_altphone")));

                    patient.Email = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_email")));

                    patient.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_password")));

                    patient.AddressLine1 = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_address_line1")));

                    patient.AddressLine2 = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_address_line2")));

                    patient.City = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_city")));

                    patient.State = Convert.ToString(dr.GetValue(dr.GetOrdinal("pt_state")));

                    patient.Zipcode = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("pt_zipcode")));



                }

                return patient;

            }
        }

        public void UpdateReportStatus(string patientId,string doctorId)
        {
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._updateReportStatus
                };

                sqlCommand.Parameters.Add(ConstantsImpl._ptId, SqlDbType.VarChar).Value = patientId;
                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = doctorId;
                sqlCommand.Parameters.Add(ConstantsImpl._reportStatus, SqlDbType.VarChar).Value = ConstantsImpl._availableStatus;
                sqlCommand.ExecuteNonQuery();
            }

        }

        public Patient DisplaySpecificPatient(string email)
        {
            Patient patient = new Patient();
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._displayFilteredPatient
                };
                sqlCommand.Parameters.Add(ConstantsImpl._email, SqlDbType.VarChar).Value = email;
                SqlDataReader dataReader = sqlCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    patient.PatientId = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._patientId)));
                    patient.FirstName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._ptFirstName)));
                    patient.LastName = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._ptLastName)));
                }
                return patient;
            }
        }
    }
}
