﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            lblDoctorId.Text = Request.QueryString["DoctorId"].ToString();
            if (lblDoctorId.Text != null || lblDoctorId.Text != "") {
                DoctorDaoSqlImpl doc = new DoctorDaoSqlImpl();
                Doctor doctor = doc.DisplaySpecficDoctorById(lblDoctorId.Text);
                lblDoctorFirstName.Text = doctor.FirstName;
                lblDoctorLastName.Text = doctor.LastName;
                lblAge.Text = doctor.Age.ToString();
                lblGender.Text = doctor.Gender;
                lblDob.Text = doctor.DateOfBirth;
                lblPhone.Text = doctor.Phone.ToString();
                lblAlternatePhone.Text = doctor.AlternatePhone.ToString();
                lblEmail.Text = doctor.Email;
                lblAddressLine1.Text = doctor.AddressLine1;
                lblAddressLine2.Text = doctor.AddressLine2;
                lblCity.Text = doctor.City;
                lblState.Text = doctor.State;
                lblZipcode.Text = doctor.Zipcode.ToString();
                lblDegree.Text = doctor.Degree;
                lblSpeciality.Text = doctor.Speciality;
                lblMedicalServiceId.Text = doctor.MedicareServiceId.ToString();
                lblWorkHours.Text = doctor.WorkHours.ToString();
                lblClinicName.Text = doctor.ClinicName;
            }
        }
    }

    protected void btnBack_Click(object sender, EventArgs e) {
        try {
            Response.Redirect("AdminPage.aspx");
        }
        catch(Exception ex) {
            Response.Write(ex.Message);
        }
    }
}