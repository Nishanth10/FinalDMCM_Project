﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.dao;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

    }

    protected void btnSaveMedicare_Click(object sender, EventArgs e) {
        try {
            MedicareServices medicareService = new MedicareServices();
            MedicareServiceDaoSqlImpl medicareServiceDaoSqlImpl = new MedicareServiceDaoSqlImpl();
            medicareService.MedicareServiceName = txtMedicareService.Text;
            medicareService.MedicareDescription = txtDescription.Text;
            medicareService.MedicareAmount = long.Parse(txtAmount.Text);

            if (medicareServiceDaoSqlImpl.AddMedicareService(medicareService) == 1) {
                Response.Write("<script>alert('Saved Successful');window.location.href='MedicareServices.aspx'</script>");
            }
            else {
                Response.Write("<script>alert('Saved Failed');window.location.href='MedicareServices.aspx'</script>");
            }
        }
        catch (Exception) {
            Response.Redirect("ErrorPage.aspx");
        }
    }
}