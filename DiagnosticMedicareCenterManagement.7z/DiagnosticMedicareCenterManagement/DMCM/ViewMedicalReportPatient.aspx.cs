﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            viewReportPanel.Visible = true;
            lblNoRecord.Visible = false;

            lbl_PatientId_text.Text = Session["patientId"].ToString();
            lbl_DoctorId_text.Text = Session["doctorId"].ToString();
            lbl_ServiceDate_text.Text = Session["apDate"].ToString();
            try {
                MedicalHistoryDaoSqlImpl medicalTestHistoryDao = new MedicalHistoryDaoSqlImpl();
                MedicalTestHistory medicalTestHistoryList = medicalTestHistoryDao.DisplaySpecificDoctorMedicalTestHistory(lbl_PatientId_text.Text, lbl_DoctorId_text.Text, lbl_ServiceDate_text.Text);
                lbl_TestResultDate_text.Text = medicalTestHistoryList.TestResultDate;
                lbl_Diag1Actual_text.Text = medicalTestHistoryList.Diag1ActualValue.ToString();
                lbl_Diag1Normal_text.Text = medicalTestHistoryList.Diag1NormalRange.ToString();
                lbl_Diag2Actual_text.Text = medicalTestHistoryList.Diag2ActualValue.ToString();
                lbl_diag2Normal_text.Text = medicalTestHistoryList.Diag2NormalRange.ToString();
                lbl_Diag3Actual_text.Text = medicalTestHistoryList.Diag3ActualValue.ToString();
                lbl_diag3Normal_text.Text = medicalTestHistoryList.Diag3NormalRange.ToString();
                lbl_Diag4Actual_text.Text = medicalTestHistoryList.Diag4ActualValue.ToString();
                lbl_diag4Normal_text.Text = medicalTestHistoryList.Diag4NormalRange.ToString();
                lbl_Diag5Actual_text.Text = medicalTestHistoryList.Diag5ActualValue.ToString();
                lbl_diag5Normal_text.Text = medicalTestHistoryList.Diag5NormalRange.ToString();
                lbl_Diag6Actual_text.Text = medicalTestHistoryList.Diag6ActualValue.ToString();
                lbl_diag6Normal_text.Text = medicalTestHistoryList.Diag6NormalRange.ToString();
                lbl_DoctorComments_text.Text = medicalTestHistoryList.DoctorComments;
                lbl_OtherInfo_text.Text = medicalTestHistoryList.OtherInfo;
            }
            catch(AppointmentEmptyException appointmentException) {
                viewReportPanel.Visible = false;
                lblNoRecord.Text = appointmentException.ToString();
                lblNoRecord.Visible = true;
            }
        }
    }

    protected void btnBack_Click(object sender, EventArgs e) {
        try {
            Response.Redirect("Patient.aspx");
        }
        catch (Exception ex) {
            Response.Write(ex.Message);
        }
    }
}
