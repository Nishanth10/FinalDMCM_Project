﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.util;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if(!IsPostBack) {
            string doctorId = Session["doctorId"].ToString();
            if (doctorId == null) {
                Response.Redirect("ErrorPage.aspx");
            }
            else {
                lblMsId.Visible = false;
                DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
                if (doctorId != null || doctorId != "") {
                    Doctor doctor = doctorDao.GetDoctor(doctorId);
                    lblFirstName.Text = doctor.FirstName;
                    lblLastName.Text = doctor.LastName;
                    lblSpeciality.Text = doctor.Speciality;
                    long phone = doctor.Phone;
                    lblPhone.Text = phone.ToString();
                    lblEmail.Text = doctor.Email;
                    lblWorkHours.Text = doctor.WorkHours.ToString();
                    lblMsId.Text = doctor.MedicareServiceId.ToString();
                }
            }
        }
    }

    protected void btnBookAppointment_Click(object sender, EventArgs e) {
        try {
            int result = 0;
            string doctorId = Session["doctorId"].ToString();
            string patientId = Session["patientId"].ToString();
            AppointmentDaoSqlImpl appointmentDao = new AppointmentDaoSqlImpl();
            Appointment appointment = new Appointment();
            appointment.MedicareServiceId = long.Parse(lblMsId.Text);
            appointment.AppointmentDate = DateUtil.convertToDate(txtDate.Text);
            result = appointmentDao.CheckAppointment(appointment.AppointmentDate, patientId, doctorId);
            if (result == 0) {
                Response.Write("<script>alert('Already Booked With Same Date!!');window.location.href='BookAppointment.aspx'</script>");
            }
            else {
                result = appointmentDao.BookAppointment(patientId, doctorId, appointment);
                if (result == 1) {
                    Response.Write("<script>alert('Appointment Booked');window.location.href='Patient.aspx'</script>");
                }
                else {
                    Response.Write("<script>alert('Try Again!!');window.location.href='BookAppointment.aspx'</script>");
                }
            }
        }
        catch (Exception ex) {
            Response.Redirect("BookAppointment.aspx");
        }
    }

    protected void btnBookCancel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("Patient.aspx");
        }
        catch (Exception ex)
        {

            Response.Write(ex.Message);
        }
    }
}