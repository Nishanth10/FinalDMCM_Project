﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if(!IsPostBack) {
            lblId.Visible = false;
            lblName.Visible = false;
        }
        string email = Session["email"].ToString();
        Doctor doctor = new Doctor();
        DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
        doctor = doctorDao.DisplaySpecificDoctor(email);
        lblId.Text = doctor.DoctorId;
        lblName.Text = doctor.FirstName + " " + doctor.LastName;
        lblId.Visible = true;
        lblName.Visible = true;
    }

    protected void btnDoctorOk_Click(object sender, EventArgs e) {
        try {
            Response.Redirect("Home.aspx");
        }
        catch (Exception ex) {
            Response.Write(ex.Message);
        }
    }
}