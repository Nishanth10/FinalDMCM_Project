﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            string date = Session["apDate"].ToString();
            DateTime apDate = DateTime.Parse(date);
            txtPatientId.Text = Session["patientId"].ToString();
            txtDoctorId.Text = Session["doctorId"].ToString();
            txtServiceDate.Text = apDate.ToString("dd/MM/yyyy");
            txtMedicareId.Visible = false;
            txtReportId.Visible = false;
            if (txtPatientId.Text != null || txtPatientId.Text != "") {
                MedicalHistoryDaoSqlImpl medicalTestHistoryDao = new MedicalHistoryDaoSqlImpl();
                MedicalTestHistory medicalTestHistory = medicalTestHistoryDao.DisplaySpecificDoctorMedicalTestHistory(txtPatientId.Text, txtDoctorId.Text, txtServiceDate.Text);
                txtMedicareId.Text = medicalTestHistory.MedicareServiceId.ToString();
                txtTestResultDate.Text = medicalTestHistory.TestResultDate;
                txtDiag1Actual.Text = medicalTestHistory.Diag1ActualValue.ToString();
                TxtDiag1Normal.Text = medicalTestHistory.Diag1NormalRange.ToString();
                txtDiag2Actual.Text = medicalTestHistory.Diag2ActualValue.ToString();
                txtDiag2Normal.Text = medicalTestHistory.Diag2NormalRange.ToString();
                txtDiag3Actual.Text = medicalTestHistory.Diag3ActualValue.ToString();
                txtDiag3Normal.Text = medicalTestHistory.Diag3NormalRange.ToString();
                txtDiag4Actual.Text = medicalTestHistory.Diag4ActualValue.ToString();
                txtDiag4Normal.Text = medicalTestHistory.Diag4NormalRange.ToString();
                txtDiag5Actual.Text = medicalTestHistory.Diag5ActualValue.ToString();
                txtDiag5Normal.Text = medicalTestHistory.Diag5NormalRange.ToString();
                txtDiag6Actual.Text = medicalTestHistory.Diag6ActualValue.ToString();
                txtDiag6Normal.Text = medicalTestHistory.Diag6NormalRange.ToString();
                txtDocComments.Text = medicalTestHistory.DoctorComments;
                txtOtherInfo.Text = medicalTestHistory.OtherInfo;

            }
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e) {
        try {
            MedicalHistoryDaoSqlImpl medicalTestHistoryDao = new MedicalHistoryDaoSqlImpl();
            MedicalTestHistory medicalTestHistory = new MedicalTestHistory();
            medicalTestHistory.PatientId = txtPatientId.Text;
            medicalTestHistory.DoctorId = txtDoctorId.Text;
            medicalTestHistory.MedicareServiceId = long.Parse(txtMedicareId.Text);
            medicalTestHistory.ServiceDate = txtServiceDate.Text;
            medicalTestHistory.TestResultDate = txtTestResultDate.Text;
            medicalTestHistory.Diag1ActualValue = long.Parse(txtDiag1Actual.Text);
            medicalTestHistory.Diag1NormalRange = long.Parse(TxtDiag1Normal.Text);
            if (txtDiag2Actual.Text == "") {
                medicalTestHistory.Diag2ActualValue = 0;
            }
            else {
                medicalTestHistory.Diag2ActualValue = long.Parse(txtDiag2Actual.Text);
            }
            if (txtDiag2Normal.Text == "") {
                medicalTestHistory.Diag2NormalRange = 0;
            }
            else {
                medicalTestHistory.Diag2NormalRange = long.Parse(txtDiag2Normal.Text);
            }
            if (txtDiag3Actual.Text == "") {
                medicalTestHistory.Diag3ActualValue = 0;
            }
            else {
                medicalTestHistory.Diag3ActualValue = long.Parse(txtDiag3Actual.Text);
            }
            if (txtDiag3Normal.Text == "") {
                medicalTestHistory.Diag3NormalRange = 0;
            }
            else {
                medicalTestHistory.Diag3NormalRange = long.Parse(txtDiag3Normal.Text);
            }
            if (txtDiag4Actual.Text == "") {
                medicalTestHistory.Diag4ActualValue = 0;
            }
            else {
                medicalTestHistory.Diag4ActualValue = long.Parse(txtDiag4Actual.Text);
            }
            if (txtDiag4Normal.Text == "") {
                medicalTestHistory.Diag4NormalRange = 0;
            }
            else {
                medicalTestHistory.Diag4NormalRange = long.Parse(txtDiag4Normal.Text);
            }
            if (txtDiag5Actual.Text == "") {
                medicalTestHistory.Diag5ActualValue = 0;
            }
            else {
                medicalTestHistory.Diag5ActualValue = long.Parse(txtDiag5Actual.Text);
            }
            if (txtDiag5Normal.Text == "") {
                medicalTestHistory.Diag5NormalRange = 0;
            }
            else {
                medicalTestHistory.Diag5NormalRange = long.Parse(txtDiag5Normal.Text);
            }
            if (txtDiag6Actual.Text == "") {
                medicalTestHistory.Diag6ActualValue = 0;
            }
            else {
                medicalTestHistory.Diag6ActualValue = long.Parse(txtDiag6Actual.Text);
            }
            if (txtDiag6Normal.Text == "") {
                medicalTestHistory.Diag6NormalRange = 0;
            }
            else {
                medicalTestHistory.Diag6NormalRange = long.Parse(txtDiag6Normal.Text);
            }

            medicalTestHistory.DoctorComments = txtDocComments.Text;
            medicalTestHistory.OtherInfo = txtOtherInfo.Text;

            medicalTestHistoryDao.EditMedicalHistory(medicalTestHistory);
            Response.Write("<script>alert('Updated Succesfully');window.location.href='DoctorPage.aspx'</script>");
        }
        catch (Exception ex) {
            Response.Write(ex.Message);
       }
    }

    protected void btnCancel_Click(object sender, EventArgs e) {
        try {
            Response.Redirect("DoctorPage.aspx");
        }
        catch (Exception ex) {
            Response.Write(ex.Message);
        }
    }

    protected void btnReset_Click(object sender, EventArgs e) {
        try {
            Response.Redirect("UpdateMedicalReport.aspx");
        }
        catch (Exception ex) {
            Response.Write(ex.Message);
        }
    }
}
