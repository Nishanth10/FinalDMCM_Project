﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.dao;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            txtMedicareServiceId.Visible = false;
            txtMedicareServiceId.Text = Session["medicareId"].ToString();
            if (txtMedicareServiceId.Text != null || txtMedicareServiceId.Text != "")  {
                MedicareServiceDaoSqlImpl medicareServiceDaoSqlImpl = new MedicareServiceDaoSqlImpl();
                MedicareServices medicareServices = medicareServiceDaoSqlImpl.GetSpecificMedicareServicesById(long.Parse(txtMedicareServiceId.Text));
                txtMedicareService.Text = medicareServices.MedicareServiceName;
                txtDescription.Text = medicareServices.MedicareDescription;
                txtAmount.Text = medicareServices.MedicareAmount.ToString();
            }
        }
    }

    protected void btnUpdateMedicare_Click(object sender, EventArgs e) {
        try {
            MedicareServices medicareService = new MedicareServices();
            MedicareServiceDaoSqlImpl medicareServiceDaoSqlImpl = new MedicareServiceDaoSqlImpl();
            medicareService.MedicareServiceId = long.Parse(Session["medicareId"].ToString());
            medicareService.MedicareServiceName = txtMedicareService.Text;
            medicareService.MedicareDescription = txtDescription.Text;
            medicareService.MedicareAmount = long.Parse(txtAmount.Text);

            if (medicareServiceDaoSqlImpl.ModifyMedicareService(medicareService) == 1) {
                Response.Write("<script>alert('Saved Successful');window.location.href='AdminPage.aspx'</script>");
            }
            else {
                Response.Write("<script>alert('Update Failed');window.location.href='AdminPage.aspx'</script>");
            }
        }
        catch (Exception) {
            Response.Redirect("ErrorPage.aspx");
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e) {
        try {
            Response.Redirect("AdminPage.aspx");
        }
        catch (Exception ex) {
            Response.Write(ex.Message);
        }
    }
}