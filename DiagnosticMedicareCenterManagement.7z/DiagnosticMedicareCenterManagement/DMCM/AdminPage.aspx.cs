﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            lblAdminDetails.Text = Session["adminName"].ToString()+" ["+Session["adminId"].ToString()+"]";
            PatientPanel.Visible = false;
            DoctorPanel.Visible = false;
            MedicareServicePanel.Visible = false;
        }
    }

    protected void btnPatient_Click(object sender, EventArgs e) {
        try {
            PatientPanel.Visible = true;
            MedicareServicePanel.Visible = false;
            DoctorPanel.Visible = false;
            PatientDaoSqlImpl pa = new PatientDaoSqlImpl();
            List<com.cognizant.dmcm.model.Patient> patientList =
                pa.DisplayPatient();
            gridPatient.DataSource = patientList;
            gridPatient.DataBind();
        }
        catch (Exception) {
            Response.Redirect("ErrorPage.aspx");
        }
    }

    protected void btnDoctor_Click(object sender, EventArgs e) {
        try {
            DoctorPanel.Visible = true;
            PatientPanel.Visible = false;
            MedicareServicePanel.Visible = false;
            DoctorDaoSqlImpl doc = new DoctorDaoSqlImpl();
            List<com.cognizant.dmcm.model.Doctor> doctorList =
                doc.DisplayDoctor();
            gridDoctor.DataSource = doctorList;
            gridDoctor.DataBind();
        }
        catch (Exception) {
            Response.Redirect("ErrorPage.aspx");
        }
    }

    protected void btnMedicareService_Click(object sender, EventArgs e) {
        try  {
            MedicareServicePanel.Visible = true;
            DoctorPanel.Visible = false;
            PatientPanel.Visible = false;
            MedicareServiceDaoSqlImpl medicareServiceDao = new MedicareServiceDaoSqlImpl();
            List<MedicareServices> medicareServiceList = medicareServiceDao.GetAllMedicareServices();
            gridMedicareService.DataSource = medicareServiceList;
            gridMedicareService.DataBind();
        }
        catch (Exception) {
            Response.Redirect("ErrorPage.aspx");
        }
    }

    protected void gridPatient_RowCommand(object sender, GridViewCommandEventArgs e) {
        PatientPanel.Visible = true;
        if (e.CommandName == "details") {
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            string patientId = gridPatient.Rows[gridviewrowindex].Cells[0].Text;
            Response.Redirect("AdminPatientDetails.aspx?PatientId=" + patientId);
        }
        if (e.CommandName == "approve") {
            PatientDaoSqlImpl pa = new PatientDaoSqlImpl();
            Patient patient = new Patient();
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            patient.PatientId = gridPatient.Rows[gridviewrowindex].Cells[0].Text;
            patient.PatientStatus = gridPatient.Rows[gridviewrowindex].Cells[3].Text;
            int result = pa.PatientStatusApprove(patient);
            if(result == 1) {
                Response.Write("<script>alert('Patient Status is Approved');window.location.href='AdminPage.aspx'</script>");
            }
            else {
                Response.Write("<script>alert('Patient Status is Already Approved');window.location.href='AdminPage.aspx'</script>");
                
            }
        }
        if (e.CommandName == "reject") {
            PatientDaoSqlImpl pa = new PatientDaoSqlImpl();
            Patient patient = new Patient();
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            patient.PatientId = gridPatient.Rows[gridviewrowindex].Cells[0].Text;
            patient.PatientStatus = gridPatient.Rows[gridviewrowindex].Cells[3].Text;
            int result = pa.PatientStatusReject(patient);
            if (result == 1) {
                Response.Write("<script>alert('Patient Status is Rejected');window.location.href='AdminPage.aspx'</script>");               
            }
            else {
                Response.Write("<script>alert('Patient Status is Already Rejected');window.location.href='AdminPage.aspx'</script>");     
            }
        }
    }

    protected void gridDoctor_RowCommand(object sender, GridViewCommandEventArgs e) {
        if (e.CommandName == "details") {
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            string doctorId = gridDoctor.Rows[gridviewrowindex].Cells[0].Text;
            Response.Redirect("AdminDoctorDetails.aspx?DoctorId=" + doctorId);
        }
        if(e.CommandName == "approve") {
            DoctorDaoSqlImpl doc = new DoctorDaoSqlImpl();
            Doctor doctor = new Doctor();
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            doctor.DoctorId = gridDoctor.Rows[gridviewrowindex].Cells[0].Text;
            doctor.DoctorStatus = gridDoctor.Rows[gridviewrowindex].Cells[3].Text;
            int result = doc.DoctorStatusApprove(doctor);
            if (result == 1) {
                Response.Write("<script>alert('Doctor Status is Approved');window.location.href='AdminPage.aspx'</script>");
            }
            else {
                Response.Write("<script>alert('Doctor Status is Already Approved');window.location.href='AdminPage.aspx'</script>"); 
            }
        }
        if(e.CommandName == "reject") {
            DoctorDaoSqlImpl doc = new DoctorDaoSqlImpl();
            Doctor doctor = new Doctor();
            int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
            doctor.DoctorId = gridDoctor.Rows[gridviewrowindex].Cells[0].Text;
            doctor.DoctorStatus = gridDoctor.Rows[gridviewrowindex].Cells[3].Text;
            int result = doc.DoctorStatusReject(doctor);
            if (result == 1) {
                Response.Write("<script>alert('Doctor Status is Rejected');window.location.href='AdminPage.aspx'</script>");       
            }
            else {
                Response.Write("<script>alert('Doctor Status is Already Rejected');window.location.href='AdminPage.aspx'</script>");             
            }
        }
    }

    protected void gridMedicareService_RowEditing(object sender, GridViewEditEventArgs e) {
        MedicareServices medicareServices = new MedicareServices();
        GridViewRow row = gridMedicareService.Rows[e.NewEditIndex];
        string medicareServiceId = row.Cells[0].Text;
        Session["medicareId"] = medicareServiceId;
        Response.Redirect("UpdateMedicareServices.aspx");
    }
}