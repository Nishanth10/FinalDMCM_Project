insert into [medicare_services] values('Surgeon','To do Surgery',50000);
insert into [medicare_services] values('Dentist','Treatment for Tooth Decays',13000);
insert into [medicare_services] values('ENT','Checkup for Ears Nose Throats',8000);
insert into [medicare_services] values('Eye Specialist','Cure Eye Problems',20000);
insert into [medicare_services] values('Child Specialist','Treatment for Children',22000);

select * from [medicare_services];

