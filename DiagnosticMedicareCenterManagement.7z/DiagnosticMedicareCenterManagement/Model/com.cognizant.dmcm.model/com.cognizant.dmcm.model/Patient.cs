﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.model {
        public class Patient : Appointment {
            private string _patientId;
            private string _firstName;
            private string _lastName;
            private int _age;
            private string _gender;
            private string _dateOfBirth;
            private long _phone;
            private long _alternatePhone;
            private string _email;
            private string _password;
            private string _addressLine1;
            private string _addressLine2;
            private string _city;
            private string _state;
            private long _zipcode;
            private string _patientStatus;

            public Patient() {

            }

            public Patient(string patientId, string firstName, string lastName, int age, string gender, string dateOfBirth, long phone, long alternatePhone, string email, string password, string addressLine1, string addressLine2, string city, string state, long zipcode,string patientStatus) {
                this._patientId = patientId;
                this._firstName = firstName;
                this._lastName = lastName;
                this._age = age;
                this._gender = gender;
                this._dateOfBirth = dateOfBirth;
                this._phone = phone;
                this._alternatePhone = alternatePhone;
                this._email = email;
                this._password = password;
                this._addressLine1 = addressLine1;
                this._addressLine2 = addressLine2;
                this._city = city;
                this._state = state;
                this._zipcode = zipcode;
                this._patientStatus = patientStatus;
            }

            public string PatientId {
                get {
                    return _patientId;
                }

                set {
                    _patientId = value;
                }
            }

            public string FirstName {
                get {
                    return _firstName;
                }

                set {
                    _firstName = value;
                }
            }

            public string LastName {
                get {
                    return _lastName;
                }

                set {
                    _lastName = value;
                }
            }

            public int Age {
                get {
                    return _age;
                }

                set {
                    _age = value;
                }
            }

            public string Gender {
                get {
                    return _gender;
                }

                set {
                    _gender = value;
                }
            }

            public string DateOfBirth {
                get {
                    return _dateOfBirth;
                }

                set {
                    _dateOfBirth = value;
                }
            }

            public long Phone {
                get {
                    return _phone;
                }

                set {
                    _phone = value;
                }
            }

            public long AlternatePhone {
                get {
                    return _alternatePhone;
                }

                set {
                    _alternatePhone = value;
                }
            }

            public string Email {
                get {
                    return _email;
                }

                set {
                    _email = value;
                }
            }

            public string Password {
                get {
                    return _password;
                }

                set {
                    _password = value;
                }
            }

            public string AddressLine1 {
                get {
                    return _addressLine1;
                }

                set {
                    _addressLine1 = value;
                }
            }

            public string AddressLine2 {
                get {
                    return _addressLine2;
                }

                set {
                    _addressLine2 = value;
                }
            }

            public string City {
                get {
                    return _city;
                }

                set {
                    _city = value;
                }
            }

            public string State {
                get {
                    return _state;
                }

                set {
                    _state = value;
                }
            }

            public long Zipcode {
                get {
                    return _zipcode;
                }

                set {
                    _zipcode = value;
                }
            }
        public string PatientStatus {
            get {
                return _patientStatus;
            }

            set {
                _patientStatus = value;
            }
        }
    }
}
