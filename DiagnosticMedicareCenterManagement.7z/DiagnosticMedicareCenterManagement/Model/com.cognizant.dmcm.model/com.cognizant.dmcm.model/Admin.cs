﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.model {
    public class Admin {
        private string _adminId;
        private string _firstName;
        private string _lastName;
        private int _age;
        private string _gender;
        private string _dateOfBirth;
        private long _phone;
        private long _alternatePhone;
        private string _email;
        private string _password;

        public Admin() {

        }

        public Admin(string _adminId, string _firstName, string _lastName, int _age, string _gender, string _dateOfBirth, long _phone, long _alternatePhone, string _email, string _password) {
            this.AdminId = _adminId;
            this.FirstName = _firstName;
            this.LastName = _lastName;
            this.Age = _age;
            this.Gender = _gender;
            this.DateOfBirth = _dateOfBirth;
            this.Phone = _phone;
            this.AlternatePhone = _alternatePhone;
            this.Email = _email;
            this.Password = _password;
        }

        public string AdminId {
            get {
                return _adminId;
            }

            set {
                _adminId = value;
            }
        }

        public string FirstName {
            get {
                return _firstName;
            }

            set {
                _firstName = value;
            }
        }

        public string LastName {
            get {
                return _lastName;
            }

            set {
                _lastName = value;
            }
        }

        public int Age {
            get {
                return _age;
            }

            set {
                _age = value;
            }
        }

        public string Gender {
            get {
                return _gender;
            }

            set {
                _gender = value;
            }
        }

        public string DateOfBirth {
            get {
                return _dateOfBirth;
            }

            set {
                _dateOfBirth = value;
            }
        }

        public long Phone {
            get {
                return _phone;
            }

            set {
                _phone = value;
            }
        }

        public long AlternatePhone {
            get {
                return _alternatePhone;
            }

            set {
                _alternatePhone = value;
            }
        }

        public string Email {
            get {
                return _email;
            }

            set {
                _email = value;
            }
        }

        public string Password {
            get {
                return _password;
            }

            set {
                _password = value;
            }
        }
    }
}
